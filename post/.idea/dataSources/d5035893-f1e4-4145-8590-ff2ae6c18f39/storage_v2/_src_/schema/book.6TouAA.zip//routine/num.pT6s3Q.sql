create procedure num(IN p int)
  begin
	set @a=0;
	repeat set @a=@a+1;
until @a>p end repeat;
end;

