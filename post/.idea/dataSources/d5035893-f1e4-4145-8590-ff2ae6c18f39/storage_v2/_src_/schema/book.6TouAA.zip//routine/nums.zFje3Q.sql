create procedure nums(IN p int)
  begin
      set @c=0;set @d=0;
      repeat
      set @c=@c+1;
      set @d=@d+@c;
      until @c=p end repeat;
    end;

